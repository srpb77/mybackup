# Laravel DataTables Buttons Plugin CHANGELOG.

## v11.0.0 - 2024-03-14

- Laravel 11.x support

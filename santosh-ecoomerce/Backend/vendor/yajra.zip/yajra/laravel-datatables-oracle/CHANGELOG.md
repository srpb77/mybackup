# Laravel DataTables 

## CHANGELOG

### [Unreleased]

### [v11.1.2](https://github.com/yajra/laravel-datatables/compare/v11.1.1...v11.1.2) - 2024-07-03

- fix: ErrorException when direction is null #3154

### [v11.1.1](https://github.com/yajra/laravel-datatables/compare/v11.1.0...v11.1.1) - 2024-04-16

- fix: mariadb support for scout search #3146

### [v11.1.0](https://github.com/yajra/laravel-datatables/compare/v11.0.0...v11.1.0) - 2024-04-16

- feat: Optimize simple queries #3135
- fix: #3133

### [v11.0.0](https://github.com/yajra/laravel-datatables/compare/v11.0.0...master) - 2024-03-14

- Laravel 11 support


[Unreleased]: https://github.com/yajra/laravel-datatables/compare/v11.0.0...master


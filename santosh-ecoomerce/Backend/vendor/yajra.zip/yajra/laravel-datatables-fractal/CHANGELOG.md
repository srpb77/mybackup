# Laravel DataTables Fractal Plugin

## Changelog

### v11.0.0 - 2024-03-14

- Add support for Laravel 11

### v10.0.0 - 2023-02-07

- Add support for Laravel 10

### v9.1.0 - 2022-06-20

- Update league/fractal to latest version #30

### v9.0.0 - 2022-05-07

- Add support for Laravel 9
- Fix https://github.com/yajra/laravel-datatables-fractal/issues/27
- Add phpstan static analysis
- Bump major version to match with the framework

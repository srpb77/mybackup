# Laravel DataTables Complete Package

## Change Log

### v11.0.0 - 2024-03-16

- Add Laravel 11 support

### v10.1.0 - 2023-02-20

- Install export package by default.

### v10.0.0 - 2023-02-07

- Add Laravel 10 specific support

### v9.0.0 - 2022-05-08

- Add Laravel 9 specific support
- Match package major version with the framework

<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Hidden extends Field
{
    protected string $type = 'hidden';
}

# Upgrade Notes

## v10 to v11

- Editor `scope` method has been renamed to `formScope`.
